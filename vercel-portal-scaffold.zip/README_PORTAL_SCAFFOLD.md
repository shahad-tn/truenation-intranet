# True Nation Portal — Phase 1 & 2 scaffold

Drop-in files that add the gated staff portal to your existing Next.js app
(`github.com/shahad-tn/truenation`). This covers **Phase 1** (portal routes)
and **Phase 2** (the NextAuth + Google login wall, restricted to
`@truenation.org`) from the migration runbook.

> **Do not push straight to `main`.** `main` auto-deploys to Vercel. Put these
> on a branch and use a Vercel **preview** deployment to test, then merge only
> after the login and pages check out. Nothing here should touch production or
> the public Squarespace site.

---

## What's included

```
middleware.js                              ← gates /portal/* and /directory
.env.portal.example                        ← the new env vars (copy into .env.local + Vercel)
app/
  api/auth/[...nextauth]/route.js          ← NextAuth: Google provider + @truenation.org gate
  portal/
    layout.js                              ← portal chrome (nav, fonts, brand)
    page.js                                ← portal home (placeholder tiles)
    portal.module.css                      ← brand styles, light + dark, WCAG-minded
  directory/route.js                       ← redirects to the GAS directory (link, NOT iframe)
```

Your existing `app/onboarding`, `app/setup`, and the onboarding API routes are
**untouched** and stay public.

---

## 1. Copy the files in

Merge this tree into the repo root, preserving paths. If your app uses a `src/`
directory, place `app/...` under `src/app/...` and keep `middleware.js` at the
repo root (or in `src/`) as your project already does.

## 2. Install NextAuth (v4)

```bash
npm install next-auth@^4
```

> This scaffold targets **NextAuth v4** (imports `next-auth/providers/google`,
> `next-auth/middleware`). Don't install v5/Auth.js beta — the import paths and
> config differ.

## 3. Create the Google OAuth client (Phase 2)

This is a **new** credential, separate from your service account.

1. Google Cloud Console → **APIs & Services → Credentials**.
2. **Create credentials → OAuth client ID → Web application**.
3. Authorized redirect URIs:
   - `https://portal.truenation.org/api/auth/callback/google`
   - `http://localhost:3000/api/auth/callback/google` (local testing)
   - (add your Vercel preview URL callback too if you want to test on preview)
4. Copy the **Client ID** and **Client secret** into the env vars below.

## 4. Set environment variables

Copy `.env.portal.example` → `.env.local` for local dev, and add the same keys
in **Vercel → Settings → Environment Variables**:

| Variable | Notes |
|---|---|
| `NEXTAUTH_URL` | `https://portal.truenation.org` in prod; `http://localhost:3000` locally |
| `NEXTAUTH_SECRET` | `openssl rand -base64 32` |
| `GOOGLE_OAUTH_CLIENT_ID` | from step 3 |
| `GOOGLE_OAUTH_CLIENT_SECRET` | from step 3 |
| `GAS_DIRECTORY_URL` | the deployed Apps Script `/exec` URL for `userdirectory.html` |

Your existing `GOOGLE_SERVICE_ACCOUNT_BASE64` and `GOOGLE_ADMIN_EMAIL` stay as-is.

## 5. Test

```bash
npm run dev
```

- Visit `/portal` → you should be bounced to Google sign-in.
- Sign in with a `@truenation.org` account → you reach the portal.
- Sign in with a **non**-truenation.org Google account → you should be **refused**
  (that proves the `signIn` gate, not just the `hd` hint, is working).
- Visit `/directory` → redirects to the GAS directory as a first-party page.

Then push to a **branch**, open the Vercel **preview**, and repeat the checks
there before going anywhere near the domain (runbook Phase 4).

---

## How this maps to the runbook

- **Phase 1 — build the portal:** `app/portal/*` is the shell. Rebuild each Sites
  page as a route (e.g. `app/portal/departments/page.js`) by pasting the matching
  block from `TNIC_All_Pages_Embeds.html` — no iframe, and drop the postMessage
  height script.
- **Phase 2 — login wall:** `app/api/auth/[...nextauth]/route.js` + `middleware.js`.
  The `hd` param is a hint; the `signIn` callback is the real enforcement.
- **Phase 3 — directory & forms:** `app/directory/route.js` redirects instead of
  embedding, keeping the canonical `portal.truenation.org/directory` URL while
  serving it first-party. Profile Setup links to your existing `/setup`. **Do not
  iframe either** — third-party cookie blocking (Safari/Firefox) breaks the GAS
  session.

## Notes & choices

- **Plain JS, no semicolons, double quotes** — matches your existing app style.
- **Fonts** via `next/font` (Barlow Condensed + DM Sans) — self-hosted by Next,
  so no external font host and no CSP issues.
- **Not created:** anything under `app/api/profile` (that route was deliberately
  removed from your project — this scaffold does not bring it back).
- **Optional next step:** to serve the portal at `portal.truenation.org/` (root)
  instead of `/portal`, add a domain-aware rewrite in `next.config.js`. Left out
  here on purpose to keep the first cut simple and low-risk.
