import NextAuth from "next-auth"
import GoogleProvider from "next-auth/providers/google"

// ── True Nation portal auth ──────────────────────────────────────
// Google sign-in restricted to @truenation.org accounts.
//
// IMPORTANT: the Google `hd` param below is only a UI hint (it just
// pre-filters the account chooser). The signIn callback is the ACTUAL
// enforcement — never rely on `hd` alone, since it can be bypassed.
//
// This uses a NEW OAuth 2.0 Web client (GOOGLE_OAUTH_CLIENT_ID /
// _SECRET) — separate from the service account used by the onboarding
// API. See README_PORTAL_SCAFFOLD.md for how to create it.

const ALLOWED_DOMAIN = "truenation.org"

export const authOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_OAUTH_CLIENT_ID,
      clientSecret: process.env.GOOGLE_OAUTH_CLIENT_SECRET,
      authorization: {
        params: {
          hd: ALLOWED_DOMAIN,        // hint only — chooser pre-filter
          prompt: "select_account",
        },
      },
    }),
  ],
  session: { strategy: "jwt" },
  callbacks: {
    // Hard gate: only verified @truenation.org emails may sign in.
    async signIn({ profile }) {
      const email = (profile?.email || "").toLowerCase()
      const verified = profile?.email_verified === true
      return verified && email.endsWith("@" + ALLOWED_DOMAIN)
    },
    async jwt({ token, profile }) {
      if (profile?.email) token.email = profile.email
      return token
    },
    async session({ session, token }) {
      if (token?.email && session.user) session.user.email = token.email
      return session
    },
  },
}

const handler = NextAuth(authOptions)

export { handler as GET, handler as POST }
