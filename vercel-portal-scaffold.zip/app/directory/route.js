import { NextResponse } from "next/server"

// ── Staff Directory: LINK, don't iframe ──────────────────────────
// The Apps Script directory depends on the live Google session via the
// google.script.run bridge. Embedded as an iframe on this (non-Google)
// origin it breaks when third-party cookies are blocked (Safari/Firefox
// by default). So we serve it FIRST-PARTY: this route just redirects to
// the GAS web app, opening it as a top-level page while keeping the
// canonical portal.truenation.org/directory URL.
//
// GAS_DIRECTORY_URL = the deployed Apps Script web app /exec URL.
// This route is gated by middleware, so only signed-in staff reach it.

export function GET() {
  const url = process.env.GAS_DIRECTORY_URL
  if (!url) {
    return new NextResponse(
      "GAS_DIRECTORY_URL is not set. Add the Apps Script web app /exec URL to the environment.",
      { status: 500 },
    )
  }
  return NextResponse.redirect(url)
}
