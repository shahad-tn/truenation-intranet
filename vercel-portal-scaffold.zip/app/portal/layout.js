import Link from "next/link"
import { Barlow_Condensed, DM_Sans } from "next/font/google"
import styles from "./portal.module.css"

// Self-hosted by Next (no external font host / CSP concerns).
const display = Barlow_Condensed({
  subsets: ["latin"],
  weight: ["600", "700"],
  variable: "--font-display",
  display: "swap",
})
const body = DM_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-body",
  display: "swap",
})

export const metadata = {
  title: "True Nation Portal",
  description: "True Nation staff intranet",
}

// Directory and Profile Setup are LINKS to first-party pages, not
// iframes: /directory redirects to the GAS web app; /setup is your
// existing device-detect route. See README for why.
const NAV = [
  { href: "/portal", label: "Home" },
  { href: "/portal/departments", label: "Departments" },
  { href: "/portal/people", label: "Our People" },
  { href: "/portal/resources", label: "Resources" },
  { href: "/directory", label: "Staff Directory" },
  { href: "/setup", label: "Profile Setup" },
]

export default function PortalLayout({ children }) {
  return (
    <div className={`${display.variable} ${body.variable} ${styles.shell}`}>
      <header className={styles.nav}>
        <Link href="/portal" className={styles.brand}>
          <span className={styles.mark} aria-hidden="true">TN</span>
          <span className={styles.brandText}>True&nbsp;Nation</span>
        </Link>
        <nav className={styles.links} aria-label="Portal">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} className={styles.link}>
              {n.label}
            </Link>
          ))}
        </nav>
        <a className={styles.signout} href="/api/auth/signout">Sign out</a>
      </header>
      <main className={styles.main}>{children}</main>
      <footer className={styles.foot}>
        True Nation &middot; Staff Portal &middot; truenation.org
      </footer>
    </div>
  )
}
