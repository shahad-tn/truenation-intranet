import Link from "next/link"
import styles from "./portal.module.css"

export const metadata = { title: "Home · True Nation Portal" }

// Quick-access tiles. Internal tiles point at portal pages you'll
// rebuild from your Sites embeds (TNIC_All_Pages_Embeds.html); the
// Directory and Profile Setup tiles are first-party links (see layout).
const TILES = [
  { href: "/portal/departments", k: "Sections", label: "Departments", d: "Branches, departments, and the teams under each." },
  { href: "/portal/people", k: "Sections", label: "Our People", d: "Leadership and staff across all locations." },
  { href: "/portal/resources", k: "Sections", label: "Resources", d: "Documents, forms, and the shared library." },
  { href: "/directory", k: "Live app", label: "Staff Directory", d: "Search staff, manage profiles, admin tools.", external: true },
  { href: "/setup", k: "Live app", label: "Profile Setup", d: "Complete or update your staff profile.", external: true },
]

export default function PortalHome() {
  return (
    <>
      <section className={styles.hero}>
        <p className={styles.eyebrow}>True Nation · Staff Portal</p>
        <h1 className={styles.h1}>Welcome to the Portal</h1>
        <p className={styles.lede}>
          Everything for True Nation staff in one place. This is the new home
          of the intranet — rebuilt from the existing pages, gated to
          truenation.org accounts.
        </p>
      </section>

      <section className={styles.grid} aria-label="Quick access">
        {TILES.map((t) => (
          <Link key={t.href} href={t.href} className={styles.tile}>
            <span className={styles.tileK}>{t.k}{t.external ? " ↗" : ""}</span>
            <span className={styles.tileLabel}>{t.label}</span>
            <span className={styles.tileD}>{t.d}</span>
          </Link>
        ))}
      </section>

      <p className={styles.note}>
        Scaffold placeholder — paste each page&rsquo;s block from
        TNIC_All_Pages_Embeds.html into the matching route to finish Phase&nbsp;1.
      </p>
    </>
  )
}
