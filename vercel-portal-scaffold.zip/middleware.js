// ── Portal gate ──────────────────────────────────────────────────
// Everything matched below requires a signed-in @truenation.org
// Google account (enforced in the NextAuth signIn callback). An
// unauthenticated visitor is redirected to Google sign-in.
//
// PUBLIC (intentionally NOT matched): /onboarding, /setup, and the
// /api/auth/* endpoints. Never add /api/auth to the matcher or sign-in
// itself would be blocked.
//
// Requires NEXTAUTH_SECRET to be set.

export { default } from "next-auth/middleware"

export const config = {
  matcher: [
    "/portal/:path*",
    "/directory",
  ],
}
